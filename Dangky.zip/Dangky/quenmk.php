<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="../css/bootstrap/bootstrap.css" />
    <script src="../js/jquery/jquery-3.5.0.js"></script>
    <title>Quên mật khẩu</title>
</head>
<body>
<?php
require_once("/xampp/htdocs/Dangky/lib/connection.php");
// Dùng isset để kiểm tra Form
if (isset($_POST['quenmatkhau']))
{
$Email = $_POST['Email'];
$matkhaumoi = $_POST['Matkhaumoi'];
$Nhaplaimatkhau = $_POST['Nhaplaimatkhau'];

if($matkhaumoi!=$Nhaplaimatkhau){
    echo '<script language="javascript">alert("Nhập lại mật khẩu không khùng khớp!"); window.location="quenmk.php";</script>';
}

$sql="select * from users where Email='$Email'";
$kt=mysqli_query($conn, $sql);

  if(mysqli_num_rows($kt)  == 0){
    echo '<script language="javascript">alert("Email không tồn tại!"); window.location="quenmk.php";</script>';
  }
  else{
    $sql="update users set matkhau='$matkhaumoi' where Email='$Email'";
    mysqli_query($conn,$sql);
    echo '<script language="javascript">alert("Chúc mừng bạn đã đổi mật khẩu thành công!"); window.location="login.php";</script>';
}
}
?>
<form method="post" action="quenmk.php" class="form">

    <div id="container">
        <header>
            <div>
                <img src="mua-sam-dung-cu-hoc-tap-nam-hoc-moi-khong-nen-sam-do-qua-dat-tien-073236.jpg" width="600" height="150">
                <img src="unnamed.jpg" width="390" height="150">
            </div>
        </header>

        <nav>
            <div style="float: left;">
                <h1>HNY SHOP CHUYÊN BÁN TẤT CẢ DỤNG CỤ HỌC TẬP VÀ VĂN PHÒNG PHẨM</h1>
            </div>
        </nav>
        <div style="clear:both;"></div>

        <div id="content">
            <h2>Quên mật khẩu</h2>
            <table border="1">
                

                <tr>
                    <td>Email</td>
                    <td>
                        <input class="mytextbox" type="text" name="Email" required maxlength="100" placeholder="Nhập Email" />
                    </td>
                </tr>

                <tr>
                    <td>Mật khẩu mới</td>
                    <td>
                        <input class="mytextbox" type="password" name="Matkhaumoi" required maxlength="20" placeholder="Password mới" />
                    </td>
                </tr>

                <tr>
                    <td>Nhập lại mật khẩu</td>
                    <td>
                        <input class="mytextbox" type="password" name="Nhaplaimatkhau" required maxlength="20" placeholder="Nhập lại Password" />
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center;">
                    <button class="btn btn-success" type="submit" name="quenmatkhau">Xác nhận</button>
                    </td>
            </table>
        </div>
        <footer>
            Xin cảm ơn quý khách đã ghé ủng hộ.
        </footer>
    </div>
    
</form>

</body>

</html>