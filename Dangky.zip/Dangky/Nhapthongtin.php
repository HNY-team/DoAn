<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="../css/bootstrap/bootstrap.css" />
    <script src="../js/jquery/jquery-3.5.0.js"></script>
    <title>Đăng ký</title>
</head>
<body>
<?php
require_once("/xampp/htdocs/Dangky/lib/connection.php");
// Dùng isset để kiểm tra Form
if (isset($_POST['dangky']))
{
$Email = $_POST['Email'];
$Sodienthoai = $_POST['Sodienthoai'];
$tendangnhap = $_POST['tendangnhap'];
$matkhau = $_POST['Matkhau'];
$Nhaplaimatkhau = $_POST['Nhaplaimatkhau'];

if($matkhau!=$Nhaplaimatkhau){
    echo '<script language="javascript">alert("Nhập lại mật khẩu không đúng!"); window.location="Nhapthongtin.php";</script>';
}
  
if ($Email == "" || $Sodienthoai == "" || $tendangnhap == "" || $matkhau == "") {   
    echo '<script language="javascript">alert("Bạn vui lòng nhập đầy đủ thông tin!"); window.location="Nhapthongtin.php";</script>';
}
else{
    // Kiểm tra tài khoản đã tồn tại chưa
    $sql="select * from users where tendangnhap='$tendangnhap'";
    $kt=mysqli_query($conn, $sql);

  if(mysqli_num_rows($kt)  > 0){
    echo '<script language="javascript">alert("Tài khoản đã tồn tại!"); window.location="Nhapthongtin.php";</script>';
  }

  else{
    $sql = "INSERT INTO users(
                                Email,
                                Sodienthoai,
                                tendangnhap,
                                matkhau
                            ) VALUES (
                                '$Email',
                                '$Sodienthoai',
                                '$tendangnhap',
                                '$matkhau'
                            )";
    // thực thi câu $sql với biến conn lấy từ file connection.php
    mysqli_query($conn,$sql);
    echo '<script language="javascript">alert("Chúc mừng bạn đã đăng kí thành công!"); window.location="login.php";</script>';
}
}
}
?>
<form method="post" action="Nhapthongtin.php" class="form">
<div id="container">
        <header>
            <div>
                <img src="mua-sam-dung-cu-hoc-tap-nam-hoc-moi-khong-nen-sam-do-qua-dat-tien-073236.jpg" width="600" height="150">
                <img src="unnamed.jpg" width="390" height="150">
            </div>
        </header>
        <!--Menu ngang-->
        <nav>
            <div style="float: left;">
                <h1>HNY SHOP CHUYÊN BÁN TẤT CẢ DỤNG CỤ HỌC TẬP VÀ VĂN PHÒNG PHẨM</h1>
            </div>
        </nav>
        <div style="clear:both;"></div>
        <!--Phần nội dung trang-->
        <div id="content">
            <h2>Đăng ký</h2>
            <table border="1">
                <tr>
                    <td>Email</td>  
                    <td>
                        <input class="mytextbox" type="email" name="Email" required maxlength="100" placeholder="Nhập Emai"
                        title="Nhập địa chỉ email có đầy đủ @gmail.com"/>
                    </td>
                </tr>

                <tr>
                    <td>Số điện thoại</td>
                    <td>
                        <input class="mytextbox" type="text" name="Sodienthoai" required maxlength="15" placeholder="Nhập Số điện thoại" pattern="(\+84|0)\d{9,10}"
  title="Nhập số điện thoại từ 10 đến 11 số" />
                    </td>
                </tr>

                <tr>
                    <td>Tên đăng nhập</td>
                    <td>
                        <input class="mytexbox" type="text" name="tendangnhap" required maxlength="20" placeholder="Nhập tên đăng nhập" 
                        title="Tên đăng nhập chỉ chứa chữ thường và số không quá 20 ký tự"/>
                    </td>
                </tr>

                <tr>
                    <td>Mật khẩu</td>
                    <td>
                        <input class="mytextbox" type="password" name="Matkhau" required maxlength="20" placeholder="Nhập Password" />
                    </td>
                </tr>

                <tr>
                    <td>Nhập lại mật khẩu</td>
                    <td>
                        <input class="mytextbox" type="password" name="Nhaplaimatkhau" required maxlength="20" placeholder="Nhập lại Password" />
                    </td>
                </tr>

                <tr>
                    <td colspan="2" style="text-align: center;">
                        <div class="form-group text-center">
                            <button class="btn btn-success" type="submit" name="dangky">Đăng ký</button>
                        </div>
                    </td>
                    <div id="KetQua"></div>
            </table>
        </div>
        <footer>
            Xin cảm ơn quý khách đã ghé ủng hộ.
        </footer>
    </div>

</form>
  
</body>
</html>