<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="stylesheet" href="style.css"/>
<link rel="stylesheet" href="../css/bootstrap/bootstrap.css" />
    <script src="../js/jquery/jquery-3.5.0.js"></script>
    <title>Đăng nhập</title>


</head>

<body>

<?php
	//Gọi file connection.php ở bài trước
	require_once("/xampp/htdocs/Dangky/lib/connection.php");
	// Kiểm tra nếu người dùng đã ân nút đăng nhập thì mới xử lý
	if (isset($_POST["dangnhap"])) {
		// lấy thông tin người dùng
		$tendangnhap = $_POST["tendangnhap"];
		$matkhau = $_POST["Matkhau"];
		//làm sạch thông tin, xóa bỏ các tag html, ký tự đặc biệt 
		//mà người dùng cố tình thêm vào để tấn công theo phương thức sql injection
		$tendangnhap = strip_tags($tendangnhap);
		$tendangnhap = addslashes($tendangnhap);
		$matkhau = strip_tags($matkhau);
        $matkhau = addslashes($matkhau);
        if ($tendangnhap == "admin") {
			echo '<script language="javascript">window.location="../admin/VeiwUsers.php";</script>';
		}
		else if ($tendangnhap == "" || $matkhau =="") {
			echo '<script language="javascript">alert("Tên đăng nhập hoặc mật khẩu không được để trống!"); window.location="login.php";</script>';
		}else{
			$sql = "select * from users where tendangnhap = '$tendangnhap' and Matkhau = '$matkhau' ";
			$query = mysqli_query($conn,$sql);
			$num_rows = mysqli_num_rows($query);
			if ($num_rows==0) {
				echo '<script language="javascript">alert("Tên đăng nhập hoặc mật khẩu không đúng!"); window.location="login.php";</script>';
			}else{
				//tiến hành lưu tên đăng nhập vào session để tiện xử lý sau này
				$_SESSION['tendangnhap'] = $tendangnhap;
                // Thực thi hành động sau khi lưu thông tin vào session
                // ở đây mình tiến hành chuyển hướng trang web tới một trang gọi là index.php
                header('Location: ../TrangChu/daodien.php');
                
			}
		}
    }
    if (isset($_POST["dangky"])) {
        header('Location: Nhapthongtin.php');
            }
            if (isset($_POST["quenmatkhau"])) {
                header('Location: quenmk.php');
                    }
?>

<form method="POST" action="login.php">
    <div id="container">
        <header>
            <div>
                <img src="mua-sam-dung-cu-hoc-tap-nam-hoc-moi-khong-nen-sam-do-qua-dat-tien-073236.jpg" width="600" height="150">
                <img src="unnamed.jpg" width="390" height="150">
            </div>
        </header>

        <nav>
            <div style="float: left;">
                <h1>HNY SHOP CHUYÊN BÁN TẤT CẢ DỤNG CỤ HỌC TẬP VÀ VĂN PHÒNG PHẨM</h1>
            </div>
        </nav>
        <div style="clear:both;"></div>

        <div id="content">
            <h2>Đăng nhập</h2>
            <table border="1">
                <tr>
                    <td>Tên đăng nhập</td>
                    <td>
                        <input class="mytexbox" type="text" name="tendangnhap" maxlength="20" placeholder="Nhập tên đăng nhập" />
                    </td>
                </tr>

                <tr>
                    <td>Mật khẩu</td>
                    <td>
                        <input class="mytextbox" type="password" name="Matkhau" maxlength="50" placeholder="Mật khẩu" />
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: center;">
                        <button class="btn btn-success" type="submit" name="dangnhap">Đăng nhập</button>
                        <button class="btn btn-success" type="submit" name="quenmatkhau">Quên mật khẩu</button>
                        <br>
                        <button class="btn btn-success" type="submit" name="dangky">Đăng ký</button>
                    
                    </td>
            </table>
            <br>
            <img src="hinhdong1.gif" width="150" height="150">
            <img src="hinhdong2.gif" width="150" height="150">
            <img src="hinhdong3.gif" width="150" height="150">
        </div>
        <footer>
            Xin cảm ơn quý khách đã ghé ủng hộ.
        </footer>
    </div>
</form>
</body>

</html>