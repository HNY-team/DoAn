<?php
$server_tendangnhap = "root";
$server_matkhau = "";
$server_host = "localhost";
$database = 'datadangky';

$conn = mysqli_connect($server_host,$server_tendangnhap,$server_matkhau,$database) or die("không thể kết nối tới database");
mysqli_query($conn,"SET NAMES 'UTF8'");