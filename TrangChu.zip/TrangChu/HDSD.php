<!DOCTYPE html>
<html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="styleTT.css"/>
    <title>Hướng dẫn sử dụng trang web</title>
    </head>

    <body>
    <?php
        
        $link = mysqli_connect("localhost", "root", "", "datadangky");
        //set bộ mã tiếng việt
        mysqli_query($link, "SET NAMES UTF8 ");
        
        $query = "SELECT * FROM sanpham ORDER BY GiaBan";
        $result = mysqli_query($link, $query);

        mysqli_close($link);
        ?>
        <div id="menu_top">
        <ul>
        <li> <a href="daodien.php" title="Trang chủ"> Thoát </a> </li>
            <li> <a href="http://localhost:8080/Dangky/login.php" title="Đăng xuất" > <?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
//tiến hành kiểm tra là người dùng đã đăng nhập hay chưa
//nếu chưa, chuyển hướng người dùng ra lại trang đăng nhập

if (!isset($_SESSION['tendangnhap'])) {
	echo "Bạn chưa đăng nhập! <a href='login.php'>Nhấp vào đây để đăng nhập</a>";
}
else
{
        $tendangnhap = intval($_SESSION['tendangnhap']);
		$sql = "SELECT * FROM users WHERE tendangnhap='{$tendangnhap}'";
        echo "Chào $_SESSION[tendangnhap]."; 
}
?> 
                </a></li>
            <li> <a href="GioHang.php" title="Giỏ hàng"> Giỏ hàng</a> </li>
            <li> <a href="daodien.php" title="Trang chủ"> Trang chủ </a> </li>
            <li> <a href="HDSD.php" title="Hướng dẫn sử dụng trang web"> HDSD web </a> </li>
        </ul>
        </div> 
        <div > 
      <img src="ảnh nền1.jpg" width="100%" height="250px">
  </div>
<div id="container">
<h1>Xin kính chào quý khách, sau đây là phần hướng dẫn sử dụng trang web !!!</h1>
<h4>Dây là một trang web bán hàng đơn giản và dễ sử dụng, phù hợp với mọi lứa tuổi, có điều chúng tôi chưa có 
    chức năng tìm kiếm và phân loại sản phẩm nên kiếm hơi lâu, đó là những thiếu sót của chúng tôi. Sau đây là 
    các phần và các chức năng của trang web.<br><br>Đầu tiên là phần đăng ký thành viên, các bạn sẽ nhập thông tin lần lượt 
    từng dòng đúng theo yêu cầu, nếu sai hay trùng với tên đã đăng kí thì sẽ báo lỗi ngay lập tức. 
    đăng kí xong các bạn sẽ được chuyển sang trang chủ và lựa chọn những thứ mình muốn mua vào giỏ hàng, 
    phần giỏ hàng các bạn nhập thông tin lần chính xác để tráng sai sót khi chúng tôi giao hàng và các bạn sẽ thanh 
    toán bằng tiền mặt với shipper.<br><br>Web bán hàng của chúng tôi hiện chưa có hỗ trợ chức năng thanh toán online. 
    Và tiếp đến là phần quên mật khẩu, tại đây khi các bạn quên mật khẩu các bạn sẽ lấy lại mật khẩu bằng 
    Email mà ban đầu các bạn đăng kí, nếu nhập đúng các bạn sẽ đỗi mật khẩu thành công. Chúng 
    tôi xin hết cảm ơn chân thành đến quý khách đã ủng hộ. !!!
</h4>
</div>

        <div id="footer">
            Xin cảm ơn quý khách đã ghé ủng hộ.
        </div>
    </body>
    <script src="./TrangChu/js/jquery-3.5.0.js"></script>
    <script src="./js/bootstrap.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
</html>