<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>

    <style>
        .sanpham{width:80px; height: 100px;}
    </style>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="styleTT.css"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Trang chủ</title>
    </head>

    <body>
        
        <?php
        
        $link = mysqli_connect("localhost", "root", "", "datadangky");
        //set bộ mã tiếng việt
        mysqli_query($link, "SET NAMES UTF8 ");
        
        $query = "SELECT * FROM sanpham ORDER BY GiaBan";
        $result = mysqli_query($link, $query);

        mysqli_close($link);
        ?>
        <div id="menu_top">
        <ul>
            <li> <a href="http://localhost:8080/Dangky/login.php" title="Đăng xuất" > <?php

header('Content-Type: text/html; charset=UTF-8');
//tiến hành kiểm tra là người dùng đã đăng nhập hay chưa
//nếu chưa, chuyển hướng người dùng ra lại trang đăng nhập

if (!isset($_SESSION['tendangnhap'])) {
    echo "Bạn chưa đăng nhập! <a href='login.php'>Nhấp vào đây để đăng nhập</a>";
}
else
{
        $tendangnhap = intval($_SESSION['tendangnhap']);
		$sql = "SELECT * FROM users WHERE tendangnhap='{$tendangnhap}'";
        echo "Chào $_SESSION[tendangnhap]."; 
        
}
?> 
                </a></li>
                
            <li> <a href="http://localhost:8080/Giohang/GioHang.php" title="Giỏ hàng"> Giỏ hàng</a> </li>
            <li> <a href="http://localhost:8080/TrangChu/daodien.php" title="Trang chủ"> Trang chủ </a> </li>
            <li> <a href="HDSD.php" title="Hướng dẫn sử dụng trang web"> HDSD web </a> </li>
        </ul>
        </div>


        <div >
            <img src="mua-sam-dung-cu-hoc-tap-nam-hoc-moi-khong-nen-sam-do-qua-dat-tien-073236.jpg" width="700" height="200">
            <img src="unnamed.jpg" width="350" height="200">
        </div>


       <div id="container">

       <div id='cart'>
       
<?php

    $ok=1;
    if(isset($_SESSION['cart']))
    {
    foreach($_SESSION['cart'] as $k=>$v)
    {
    if(isset($v))
    {
    $ok=2;
    }
    }
    }
    if ($ok != 2)
    {
    echo '<p>Ban khong co mon hang nao trong gio hang</p>';
    } else {
    $items = $_SESSION['cart'];
    echo '<p>Ban dang co <a href="/GioHang/cart.php">'.count($items).' mon hang trong gio hang</a></p>';
    echo '<a href="http://localhost:8080/GioHang/index.php" target="_blank"><button class="btn btn-success" type="submit" name="mua">Mua hàng</button></a>';
    }
    ?>
    </div>







        <table border="1" cellspacing="0" cellpadding="5">
	<tr>
		<td>STT</td>
        <td>Mã sản phẩm</td>
		<td>Hình</td>
		<td>Sản phẩm</td>
        <td>Giá bán</td>
        <td>Mô tả</td>
</tr>
<?php
    $stt = 1;
	while($row = mysqli_fetch_array($result))
	{
		$gia = number_format($row['GiaBan']);
        $chuoi = <<< EOD
        <tr>
                    <td>{$stt}</td>
                    <td><span><big><b> {$row['MaSanPham']}</b></big></span></td>
                    <td><img src="SanPham/{$row['Hinh']}" class="sanpham" /></td>
                    <td><span><big><b> {$row['TenSanPham']}</b></big></span></td>
                    <td><span><big><b>   {$gia} đ </b></big></span></td>
                    <td><span><big><b> {$row['Mota']}</b></big></span></td>
                    <tr>
                 
EOD;
echo $chuoi;$stt++;
    }
    ?>
    </table>
          
                   


       </div>
        <div id="footer">
            Xin cảm ơn quý khách đã ghé ủng hộ.
        </div>
    </body>
    <script src="./TrangChu/js/jquery-3.5.0.js"></script>
    <script src="./js/bootstrap.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
</html>