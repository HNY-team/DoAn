<?php
session_start();
?>
<html>
<head>
<style>
        .sanpham{width:80px; height: 100px;}
        body{
            background-color: pink;
        }
    </style>
 <title>Giỏ hàng</title>
 <link rel="stylesheet" href="style.css" />
</head>
<body>
<h1>Giỏ hàng</h1>
<div id='cart'>
<?php
    $ok=1;
    if(isset($_SESSION['cart']))
    {
    foreach($_SESSION['cart'] as $k=>$v)
    {
    if(isset($v))
    {
    $ok=2;
    }
    }
    }
    if ($ok != 2)
    {
    echo '<p>Bạn không có món nào trong giỏ hàng</p>';
    } else {
    $items = $_SESSION['cart'];
    echo '<p>Bạn đang có <a href="cart.php">'.count($items).' món trong giỏ hàng</a></p>';
    }
    ?>
    </div>
<?php

$connection = mysqli_connect("localhost","root","", "datadangky") or
    die ("couldn't connect to localhost");				
mysqli_query($connection, "set names 'utf8'");		


$sql="SELECT * FROM sanpham order by MaSanPham desc";
$query=mysqli_query($connection,$sql);
if(mysqli_num_rows($query) > 0)
{
 while($row=mysqli_fetch_array($query))
 {
  echo "<div class=pro>";
  echo "<h3>$row[MaSanPham]</h3>";
  echo "<img src=\"SanPham/{$row['Hinh']}\" class=\"sanpham\" />";
  echo "Tên sản phẩm: $row[TenSanPham] - Giá: ".number_format($row['GiaBan'])." VND<br />";
  echo "<p align='right'><a href='addcart.php?item=$row[MaSanPham]'>Mua sản phẩm</a></p>";
  echo "</div>";
 }
}
   
?>
</body>
</html>