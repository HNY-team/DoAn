<?php
session_start();
if(isset($_POST['submit']))
{
 foreach($_POST['qty'] as $key=>$value)
 {
  if( ($value == 0) and (is_numeric($value)))
  {
   unset ($_SESSION['cart'][$key]);
  }
  elseif(($value > 0) and (is_numeric($value)))
  {
   $_SESSION['cart'][$key]=$value;
  }
 }
 header("location:cart.php");
}
?>
<html>
<head>
<style>
        .sanpham{width:80px; height: 100px;}
        body{
            background-color: pink;
        }
    </style>
 <title>Giỏ hàng</title>
 <link rel="stylesheet" href="style1.css" />
</head>
<body>
<h1>Giỏ hàng</h1>
<?php
$ok=1;
if(isset($_SESSION['cart']))
{
 foreach($_SESSION['cart'] as $k => $v)
 {
  if(isset($k))
  {
   $ok=2;
  }
 }
}
if($ok == 2)
{
 
   echo "<form action='cart.php' method='post'>";
   foreach($_SESSION['cart'] as $key=>$value)
   {
    $item[]=$key;
   }
   $str=implode(",",$item);
  
   $connection = mysqli_connect("localhost","root","", "datadangky") or
        die ("couldn't connect to localhost");				
    mysqli_query($connection, "set names 'utf8'");		

   $sql="SELECT * from sanpham where MaSanPham in ($str)";
   $query=mysqli_query($connection,$sql);
   while($row=mysqli_fetch_array($query))
   {
   echo "<div class='pro'>";
   echo "<h3>$row[MaSanPham]</h3>";
   echo "<img src=\"SanPham/{$row['Hinh']}\" class=\"sanpham\" />";
   echo "Tên sản phẩm: $row[TenSanPham] - Giá sản phẩm: ".number_format($row['GiaBan'])." VND<br />";
   echo "<p align='right'>Số lượng: <input type='text' name='qty[$row[MaSanPham]]' size='5' value='{$_SESSION['cart'][$row['MaSanPham']]}'> - ";
   echo "<a href='delcart.php?productid=$row[MaSanPham]'>Xóa sản phẩm này</a></p>";
   echo "<p align='right'> Giá tiền sản phẩm: ". number_format($_SESSION['cart'][$row['MaSanPham']]*$row['GiaBan'],3) ." VND</p>";
   echo "</div>";
   $total+=$_SESSION['cart'][$row['MaSanPham']]*$row['GiaBan'];
   }
  echo "<div class='pro' align='right'>";
  echo "<b>Tổng tiền : <font color='red'>". number_format($total)." VND</font></b>";
  echo "</div>";
  echo "<input type='submit' name='submit' value='Cập nhật Giỏ hàng'>";
  echo "<div class='pro' align='center'>";
  echo "<b><a href='index.php'>Tiếp tục mua hàng</a> - <a href='delcart.php?productid=0'>Xóa tất cả sản phẩm</a></b>";
  echo "</div>"; 
 }
else
 {
  echo "<div class='pro'>";
  echo "<p align='center'>Chưa có sản phẩm nào trong giỏ hàng<br /><a href='index   .php'>Mua sản phẩm</a></p>";
  echo "</div>";
 }
?>
</body>
</html>