<!DOCTYPE html>
<html>
<head>
<title>Sửa thông tin sản phẩm</title>
<link rel="stylesheet" href="sita.css"/>
</head>
<body>
<?php
// Kết nối Database
include 'connect.php';
$MaSanPham=$_GET['MaSanPham'];
$query=mysqli_query($conn,"select * from `sanpham` where MaSanPham='$MaSanPham'");
$row=mysqli_fetch_assoc($query);
?>
<form method="POST" class="form">
<div id="content">
<table border="1">
<h2>Sửa thông tin sản phẩm</h2>
<label>Mã Sản Phẩm: <input type="text" value="<?php echo $row['MaSanPham']; ?>" name="MaSanPham"></label><br/>
<label>Mã Loại: <input type="text" value="<?php echo $row['MaLoai']; ?>" name="MaLoai"></label><br/>
<label>Tên sản phẩm: <input type="text" value="<?php echo $row['TenSanPham']; ?>" name="TenSanPham"></label><br/>
<label>Giá Bán: <input type="text" value="<?php echo $row['GiaBan']; ?>" name="GiaBan"></label><br/>
<label>Hình: <input type="text" value="<?php echo $row['Hinh']; ?>" name="Hinh"></label><br/>
<label>Mô tả: <input type="text" value="<?php echo $row['Mota']; ?>" name="Mota"></label><br/>
<input type="submit" value="Update" name="update_sanpham">
</table>
</div>
<?php
if (isset($_POST['update_sanpham'])){
$MaSanPham=$_GET['MaSanPham'];
$MaLoai=$_POST['MaLoai'];
$TenSanPham=$_POST['TenSanPham'];
$GiaBan=$_POST['GiaBan'];
$Hinh=$_POST['Hinh'];
$Mota=$_POST['Mota'];
 
// Create connection
$conn = new mysqli("localhost", "root", "", "datadangky");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
 
$sql = "UPDATE `sanpham` SET MaLoai='$MaLoai', TenSanPham='$TenSanPham', GiaBan='$GiaBan', Hinh='$Hinh', Mota='$Mota' WHERE MaSanPham='$MaSanPham'";
 
if ($conn->query($sql) === TRUE) {
    echo '<script language="javascript">alert("Sửa thành công!"); window.location="VeiwSp.php";</script>';
} else {
echo "Error updating record: " . $conn->error;
}
 
$conn->close();
}
?>

</form>
</body>
</html>