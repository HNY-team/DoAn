<?php
include_once('connect.php');
if(isset($_REQUEST['MaSanPham']) and $_REQUEST['MaSanPham']!=""){
$MaSanPham=$_GET['MaSanPham'];
$sql = "DELETE FROM sanpham WHERE MaSanPham='$MaSanPham'";
if ($conn->query($sql) === TRUE) {
    echo '<script language="javascript">alert("Xóa thành công!"); window.location="VeiwSp.php";</script>';

} else {
echo "Error updating record: " . $conn->error;
}
 
$conn->close();
}
?>