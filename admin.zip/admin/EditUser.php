<!DOCTYPE html>
<html>
<head>
<title>Sửa tài khản khách hàng</title>
<link rel="stylesheet" href="sita.css"/>
</head>
<body>
<?php
// Kết nối Database
include 'connect.php';
$id=$_GET['id'];
$query=mysqli_query($conn,"select * from `users` where id='$id'");
$row=mysqli_fetch_assoc($query);
?>
<form method="POST" class="form">
<div id="content">
<table border="1">
<h2>Sửa tài khoản</h2>
<label>Tên đăng nhập: <input type="text" value="<?php echo $row['tendangnhap']; ?>" name="tendangnhap"></label><br/>
<label>Email: <input type="text" value="<?php echo $row['Email']; ?>" name="Email"></label><br/>
<label>Phone: <input type="text" value="<?php echo $row['Sodienthoai']; ?>" name="Sodienthoai"></label><br/>
<input type="submit" value="Update" name="update_user">
</table>
</div>
<?php
if (isset($_POST['update_user'])){
$id=$_GET['id'];
$tendangnhap=$_POST['tendangnhap'];
$Email=$_POST['Email'];
$Sodienthoai=$_POST['Sodienthoai'];
 
// Create connection
$conn = new mysqli("localhost", "root", "", "datadangky");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
 
$sql = "UPDATE `users` SET tendangnhap='$tendangnhap', Email='$Email', Sodienthoai='$Sodienthoai' WHERE id='$id'";
 
if ($conn->query($sql) === TRUE) {
    echo '<script language="javascript">alert("Sửa thành công!"); window.location="VeiwUsers.php";</script>';
} else {
echo "Error updating record: " . $conn->error;
}
 
$conn->close();
}
?>

</form>
</body>
</html>