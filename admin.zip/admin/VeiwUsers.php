<title>Bảng users</title>
<table border="1" width="1000" >
<tr width="50%">
<td>ID</td>
<td>Email</td>
<td>Số điện thoại</td>
<td>Tên đăng nhập</td>
<td>Mật khẩu</td>
</tr>
<?php
require 'connect.php';
$query=mysqli_query($conn,"select * from `users`");
while($row=mysqli_fetch_array($query)){
?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['Email']; ?></td>
<td><?php echo $row['Sodienthoai']; ?></td>
<td><?php echo $row['tendangnhap']; ?></td>
<td><?php echo $row['matkhau']; ?></td>
<td><a href="EditUser.php?id=<?php echo $row['id']; ?>">Edit</a></td>
<td><a href="Delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Bạn có muốn xóa user này?');">Delete</a></td>
</tr>
<?php
}
?>
</table>
<br>
<a href="VeiwSp.php"><button class="btn btn-success" type="submit" name="suasp">Sửa sản phẩm</button></a>