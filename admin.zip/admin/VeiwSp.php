﻿<title>Bảng sản phẩm</title>
<table border="1" width="1000" >
<tr width="50%">
<td>Mã Sản Phẩm</td>
<td>Mã loại</td>
<td>Tên Sản Phẩm</td>
<td>Giá bán</td>
<td>Hình</td>
<td>Mô tả</td>
</tr>
<?php
require 'connect.php';
$query=mysqli_query($conn,"select * from `sanpham`");
while($row=mysqli_fetch_array($query)){
?>
<tr>
<td><?php echo $row['MaSanPham']; ?></td>
<td><?php echo $row['MaLoai']; ?></td>
<td><?php echo $row['TenSanPham']; ?></td>
<td><?php echo $row['GiaBan']; ?></td>
<td><?php echo $row['Hinh']; ?></td>
<td><?php echo $row['Mota']; ?></td>
<td><a href="EditSP.php?MaSanPham=<?php echo $row['MaSanPham']; ?>">Edit</a></td>
<td><a href="DeleteSP.php?MaSanPham=<?php echo $row['MaSanPham']; ?>" onclick="return confirm('Bạn có muốn xóa sản phẩm?');">Delete</a></td>
<!-- <td><a href="DeleteSP.php?MaSanPham=<?php echo $row['MaSanPham']; ?>">Delete</a></td> -->
</tr>
<?php
}
?>
</table>