<?php
include_once('connect.php');
if(isset($_REQUEST['id']) and $_REQUEST['id']!=""){
$id=$_GET['id'];
$sql = "DELETE FROM users WHERE id='$id'";
if ($conn->query($sql) === TRUE) {
    echo '<script language="javascript">alert("Xóa thành công!"); window.location="VeiwUsers.php";</script>';

} else {
echo "Error updating record: " . $conn->error;
}
 
$conn->close();
}
?>